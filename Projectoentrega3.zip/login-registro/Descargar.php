<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Lista de Archivos de Firebase</title>
<script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-storage.js"></script>
<script>
  // Configuración de Firebase
  const firebaseConfig = {
    apiKey: "AIzaSyDVSwmmwYjpjcivDOCP67ij06g-C85SnIo",
    authDomain: "medassist-25821.firebaseapp.com",
    projectId: "medassist-25821",
    storageBucket: "medassist-25821.appspot.com",
    messagingSenderId: "261918253815",
    appId: "1:261918253815:web:8a3f8d929f9c650829e9f2",
    measurementId: "G-MQLSECHLS0"
  };
  // Inicializa Firebase
  firebase.initializeApp(firebaseConfig);
</script>
</head>
<body>

<!-- Lista donde se mostrarán los archivos -->
<ul id="lista-archivos"></ul>

<script>
  // Referencia al storage de Firebase
  const storageRef = firebase.storage().ref('Historial/');

  // Función para listar archivos
  function listarArchivos() {
    storageRef.listAll().then((result) => {
      result.items.forEach((fileRef) => {
        // Obtener la URL de descarga pública de cada archivo
        fileRef.getDownloadURL().then((url) => {
          // Crear un elemento de lista para cada archivo
          const listaArchivos = document.getElementById('lista-archivos');
          const elementoLista = document.createElement('li');
          const enlaceArchivo = document.createElement('a');
          enlaceArchivo.href = url;
          enlaceArchivo.textContent = fileRef.name;
          enlaceArchivo.target = '_blank'; // Para abrir en una nueva pestaña
          elementoLista.appendChild(enlaceArchivo);
          listaArchivos.appendChild(elementoLista);
        });
      });
    }).catch((error) => {
      // Manejar cualquier error que ocurra durante el proceso
      console.error("Error al listar los archivos:", error);
    });
  }

  // Llamar a la función al cargar la página
  window.onload = listarArchivos;
</script>

</body>
</html>
