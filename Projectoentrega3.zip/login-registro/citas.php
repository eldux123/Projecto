<?php

    session_start();

    if(!isset($_SESSION['usuario'])){
        echo'
            <script>
                alert("Por favor debes iniciar sesión");
                window.location = "index.php";
            </script>
        ';
        session_destroy();
        die(); 
    }
    
    include('php/conexion2_be.php');
    $sql="select * from citas";
    $resultado = mysqli_query($conexion,$sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Assets/css/estilos5.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>MedAssistPro</title>
</head>

<body>
    <aside class="aside" id="aside">
        <div class="head">
            <div class="profile">
                <img src="Assets/imagenes/images.png">
                <p>MedAssistPro</p>
            </div>
            <i class='bx bx-menu' id="menu"></i>
        </div>
        <div class="options" id="options">
            <div>
                <a href="bienvenida.php">
                <i class='bx bxs-home'></i>
                <span class="option" id="principal">Principal</span>
                </a>
            </div>
            <div>
                <a href="citas.php">
                <i class='bx bx-calendar-check'></i>
                <span class="option2" id="citas">Citas</span>
                </a>
            </div>
            <div>
                <a href="agentarcitas.php">
                <i class='bx bxs-edit'></i>
                <span class="option3" id="agcitas">Agendar Cita</span>
                </a>
            </div>
            <div>
                <a href="historial_medico.php">
                <i class='bx bx-note'></i>
                <span class="option4" id="historial">Historial Medico</span>
                </a>
            </div>
            <div>
                <a href="php/cerrar_sesion.php">
                <i class='bx bx-log-out'></i>
                <span class="option">Cerrar sesión</span>
                </a>
            </div>
        </div>
    </aside>
    
   
    <main><h1>Consultar citas</h1></main>
    
        <div class="Cont_todo">
            <div class="principal" id="pr">
                <center>
                <h1>Lista de Citas</h1>
                <br><br>
                
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Doc.Identidad</th>
                            <th>Telefono</th>
                            <th>Edad</th>
                            <th>EPS</th>
                            <th>Motivo</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            while($filas=mysqli_fetch_assoc($resultado)){

                        ?>
                        <tr>
                            <th><?php echo $filas['nom_completo'] ?> </th>
                            <th><?php echo $filas['email'] ?> </th>
                            <th><?php echo $filas['doc_identidad'] ?> </th>
                            <th><?php echo $filas['telefono'] ?> </th>
                            <th><?php echo $filas['edad'] ?> </th>
                            <th><?php echo $filas['eps'] ?> </th>
                            <th><?php echo $filas['motivo'] ?> </th>
                            <th><?php echo $filas['dia'] ?> </th>
                        </tr>
                            <?php
                                }
                            ?>
                    </tbody>
                </table>
                <?php
                    mysqli_close($conexion);
                ?>
                </center>
            </div>
        </div>
    
    
    <script src="Assets/js/menu.js"></script>
    
</body>
    <footer>MedAssistPro-2024</footer>
</html>