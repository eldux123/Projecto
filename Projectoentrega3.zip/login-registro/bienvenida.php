<?php

    session_start();

    if(!isset($_SESSION['usuario'])){
        echo'
            <script>
                alert("Por favor debes iniciar sesión");
                window.location = "index.php";
            </script>
        ';
        session_destroy();
        die(); 
    }
    
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Assets/css/estilos2.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>MedAssistPro</title>
</head>

<body>
    <aside class="aside" id="aside">
        <div class="head">
            <div class="profile">
                <img src="Assets/imagenes/images.png">
                <p>MedAssistPro</p>
            </div>
            <i class='bx bx-menu' id="menu"></i>
        </div>
        <div class="options" id="options">
            <div>
                <a href="bienvenida.php">
                <i class='bx bxs-home'></i>
                <span class="option" id="principal">Principal</span>
                </a>
            </div>
            <div>
                <a href="citas.php">
                <i class='bx bx-calendar-check'></i>
                <span class="option2" id="citas">Citas</span>
                </a>
            </div>
            <div>
                <a href="agentarcitas.php">
                <i class='bx bxs-edit'></i>
                <span class="option3" id="agcitas">Agendar Cita</span>
                </a>
            </div>
            <div>
                <a href="historial_medico.php">
                <i class='bx bx-note'></i>
                <span class="option4" id="historial">Historial Medico</span>
                </a>
            </div>
            <div>
                <a href="php/cerrar_sesion.php">
                <i class='bx bx-log-out'></i>
                <span class="option">Cerrar sesión</span>
                </a>
            </div>
        </div>
    </aside>
    
   
    <main>
        <div class="cont_todo">
            
            <div class="principal" id="pr">
                <h1>¡Bienvenido a MedAssistPro!</h1>

                <p>Nuestro objetivo en esta pagina es el de poder facilitar la experiencia del usuario a la hora de pedir alguna cita medica.</p>
                
                <h2>¿Quieres reservar una cita?</h2>
                
                <p>Para agendar una cita necesitaras proporcionar tu información personal, tu historial medico y los requierimientos pedidos por el medico a cargo</p>

                <p>
                    <a href="agentarcitas.php">Agenda tu primera cita</a>
                </p>

            </div>
        </div>
    </main>
    
    <script src="Assets/js/menu.js"></script>
    
</body>
    <footer>MedAssistPro-2024</footer>
</html>