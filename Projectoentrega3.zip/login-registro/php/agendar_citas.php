<?php

include('conexion2_be.php');

$nombre = $_POST['nom_completo'];
$email = $_POST['email'];
$documento = $_POST['documento'];
$tel = $_POST['tel'];
$edad = $_POST['edad'];
$eps = $_POST['eps'];
$motivo = $_POST['motivo'];
$dia = $_POST['dia'];


$fechaFormateada = date('Y-m-d', strtotime($dia));

$query = "INSERT INTO citas (nom_completo, email, doc_identidad, telefono, edad, eps, motivo, dia) 
          VALUES ('$nombre', '$email', '$documento', '$tel', '$edad', '$eps', '$motivo', '$fechaFormateada')";

$ejecutar = mysqli_query($conexion, $query);

if($ejecutar) {
    echo '
        <script>
            alert("Cita agendada exitosamente");
            window.location = "../citas.php";
        </script>
    ';
} else {
    echo '
    <script>
        alert("Intentelo nuevamente");
        window.location = "../bienvenida.php";
    </script>
    ';
}

mysqli_close($conexion);
?>