<?php
    
    
    $conexion = mysqli_connect("localhost","root", "", "login__registro_db");
    
    /*
    if($conexion){
        echo'Se ha conectado a la Base de Datos';
    }else{
        echo 'No se ha podido conectar a la Base de Datos';
    }
    */

?>