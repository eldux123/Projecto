const firebaseConfig = {
    apiKey: "AIzaSyDVSwmmwYjpjcivDOCP67ij06g-C85SnIo",
    authDomain: "medassist-25821.firebaseapp.com",
    projectId: "medassist-25821",
    storageBucket: "medassist-25821.appspot.com",
    messagingSenderId: "261918253815",
    appId: "1:261918253815:web:8a3f8d929f9c650829e9f2",
    measurementId: "G-MQLSECHLS0"
    };

    firebase.initializeApp(firebaseConfig);

    function subirArchivo() {
    var archivo = document.getElementById('archivo').files[0];
    var storageRef = firebase.storage().ref('Historial/' + archivo.name);

    storageRef.put(archivo).then(function(snapshot) {
    console.log('¡Archivo subido con éxito a la carpeta Historial!');
    // Obtener la URL de descarga pública del archivo
    storageRef.getDownloadURL().then(function(url) {
    // Crear un elemento de lista para el archivo subido
    const listaArchivos = document.getElementById('lista-archivos');
    const elementoLista = document.createElement('li');
    const enlaceArchivo = document.createElement('a');
    enlaceArchivo.href = url;
    enlaceArchivo.textContent = archivo.name;
    enlaceArchivo.target = '_blank'; // Para abrir en una nueva pestaña
    elementoLista.appendChild(enlaceArchivo);
    listaArchivos.appendChild(elementoLista);
    }).catch(function(error) {
    console.error('Error al obtener la URL de descarga del archivo:', error);
    });
    }).catch(function(error) {
    console.error('Error al subir el archivo:', error);
    });
}