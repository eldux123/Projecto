const aside = document.getElementById('aside'),
      menu = document.getElementById('menu');

menu.onclick = () => {
    aside.classList.toggle('active');
}
